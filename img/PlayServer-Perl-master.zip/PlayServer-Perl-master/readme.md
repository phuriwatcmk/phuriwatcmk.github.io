Perl - PlayServer Client  [ หยุดพัฒนาแล้ว ] 
========
It is custom client for playserver.in.th
## Usage
* [Windown] You can run with `Start.exe`
## Discord Room
https://discord.gg/Mgu73TN
